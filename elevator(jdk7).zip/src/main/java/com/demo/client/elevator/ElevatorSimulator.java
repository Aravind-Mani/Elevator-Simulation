package com.demo.client.elevator;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.demo.client.api.ElevatorButton;
import com.demo.client.api.ElevatorButtonStub;
import com.demo.client.api.ElevatorFacade;
import com.demo.client.api.ElevatorButtonCallbackImpl;

public class ElevatorSimulator {

	public static void main(String[] args) {
		new ElevatorSimulator().showElevators(2);
	}

	public void showElevators(int noOfElevator) {
		
		JFrame jframe = new JFrame();
		jframe.setSize(500, 400);
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setLayout(new BorderLayout());
		
		JPanel urlPanel = new JPanel();
		urlPanel.setLayout(new FlowLayout());
		JLabel jlabel = new JLabel("URL :: ");
		JTextField jTextField = new JTextField("http://localhost:8080/elevator/webapi/elevators",30);
		//jTextField.setSize(400, 20);
		urlPanel.add(jlabel);
		urlPanel.add(jTextField);
		jframe.add(urlPanel,BorderLayout.NORTH);
		
		String[] elevatorId = new String[noOfElevator];
		
		for(int i=0;i<noOfElevator;i++){
			elevatorId[i] = generateRandomElevatorId(4, 4);
			try {
				ElevatorVO elevatorVO = new ElevatorVO();
				elevatorVO.setElevatorId(elevatorId[i]);
				elevatorVO.setCurrentFloor(0);
				ElevatorClient.sendPost(jTextField.getText(), elevatorVO);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

		
		
		JPanel lift;
		
		JPanel liftWhole = new JPanel();
		liftWhole.setLayout(new FlowLayout());
		for (int i = 0; i < noOfElevator; i++) {
			lift = new JPanel();
			lift.setLayout(new BoxLayout(lift, BoxLayout.PAGE_AXIS));
			JLabel liftName = new JLabel(elevatorId[i]);
			lift.add(liftName);
			JButton btn;
			for (ElevatorButton elevatorButton : ElevatorButton.values()) {
				btn = new JButton(elevatorButton.toString());
				lift.add(btn);
				btn.addActionListener(new ActionListener(){

					@Override
					public void actionPerformed(ActionEvent e) {
						ElevatorButtonStub elevatorButtonStub = new ElevatorButtonStub(
								new ElevatorFacade(),
								new ElevatorButtonCallbackImpl(liftName.getText()));
						elevatorButtonStub.pressButton(elevatorButton);
						ElevatorVO elevatorVO = new ElevatorVO();
						elevatorVO.setElevatorId(liftName.getText());
						elevatorVO.setCurrentFloor(elevatorButton.getFloor());

						try {
							ElevatorClient.sendPut(jTextField.getText(), elevatorVO);
						} catch (Exception e1) {
							e1.printStackTrace();
						}
						
					}
					
				});
				/*btn.addActionListener((e) -> {
					ElevatorButtonStub elevatorButtonStub = new ElevatorButtonStub(
							new ElevatorFacade(),
							new ElevatorButtonCallbackImpl(liftName.getText()));
					elevatorButtonStub.pressButton(elevatorButton);
					ElevatorVO elevatorVO = new ElevatorVO();
					elevatorVO.setElevatorId(liftName.getText());
					elevatorVO.setCurrentFloor(elevatorButton.getFloor());

					try {
						ElevatorClient.sendPut(jTextField.getText(), elevatorVO);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				});*/
			}
			liftWhole.add(lift);
		}
		
		
		jframe.add(liftWhole,BorderLayout.CENTER);
		jframe.setVisible(true);

	}

	public String generateRandomElevatorId(int noOfChar, int noOfNumeric) {
		String alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		Random ran = new Random();

		StringBuffer genString = new StringBuffer();
		for (int i = 0; i < noOfChar; i++) {
			char genChar = alphabets.charAt(ran.nextInt(alphabets.length()));
			genString.append(genChar);
		}
		genString.append("");
		for (int i = 0; i < noOfNumeric; i++) {
			genString.append(ran.nextInt(noOfNumeric));
		}
		return genString.toString();

	}

}
