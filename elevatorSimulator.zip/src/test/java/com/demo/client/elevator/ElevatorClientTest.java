package com.demo.client.elevator;

import org.junit.Test;

import junit.framework.TestCase;

public class ElevatorClientTest extends TestCase {

	@Test
	public void test_send_post() throws Exception{
		String url = "http://localhost:8080/elevator/webapi/elevators";
		ElevatorClient elevatorClient = new ElevatorClient();
		ElevatorVO elevatorVO = new ElevatorVO();
		elevatorVO.setElevatorId("Test123");
		elevatorVO.setCurrentFloor(2);
		int statusCode = elevatorClient.sendPost(url, elevatorVO);
		assertEquals(204, statusCode);
	}
	
}
