package com.demo.client.api;

public class ElevatorButtonCallbackImpl implements ElevatorButtonCallback {

	private String lift;
	
	public ElevatorButtonCallbackImpl(String lift){
		this.lift = lift;
	}
	
	public void buttonPressed(ElevatorButton button) {
		System.out.println(lift + " Button Pressed  " + button.toString());
		//System.out.println(button.getFloor());
	}

	public void movingElevatorToFloor(int floor) {
		System.out.print(lift + " moving to floor :: ");
		System.out.println(floor);

	}

}
