package com.demo.client.api;

public class ElevatorFacade {
	
	public void moveDownOneFloor(){
		
	}
	
	public void moveUpOneFloor(){
		
	}
	
	public void lockBreaks(){
		
	}
	
	public void unlockBreaks(){
		
	}
	

}
