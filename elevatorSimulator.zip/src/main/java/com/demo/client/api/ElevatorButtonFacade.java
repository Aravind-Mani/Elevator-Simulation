package com.demo.client.api;

public interface ElevatorButtonFacade {
	public void pressButton(ElevatorButton button);
}
